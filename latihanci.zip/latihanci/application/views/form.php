<div class='col-md-12'>
    <h1 align='center'>Form Product</h1>
</div>
<div class='col-md-12'>
    <div class='panel panel-default'>
        <label>Form Product</label>
    </div>
    <div class='panel-body'>
        <?php
       // echo validation_errors("<div class='alert alert-danger'>","</div>"); 
        echo $alert; ?>
        <form method='post' class='form-horizontal'>
            <div class='form-group'>
                <label class='control-label col-md-2'> Nama Product
                </label>
                <div class='col-md-10'>
                    <input type='text' name='product' class='form-control' value="<?php echo $venus['product'];?>"/>
                    <p class="alert-danger text-left" <?=form_error('product')?></p>
                </div>
            </div>
            <div class='form-group'>
                <label class='control-label col-md-2'> Brand
                </label>
                <div class='col-md-10'>
                    <input type='text' name='brand' class='form-control' value="<?php echo $venus['brand'];?>"/>
                    <p class="alert-danger text-left" <?=form_error('brand')?></p>
                </div>
            </div>
            <div class='form-group'>
                <label class='control-label col-md-2'> Deskripsi
                </label>
                <div class='col-md-10'>
                    <textarea  name='deskripsi' class='form-control'> <?php echo $venus['deskripsi'];?></textarea>
                    <p class="alert-danger text-left" <?=form_error('deskripsi')?></p>
                </div>
            </div>
            <div class='form-group'>
                <label class='control-label col-md-2'> Barcode
                </label>
                <div class='col-md-10'>
                    <input type='text' name='barcode' class='form-control' value="<?php echo $venus['barcode'];?>"/>
                    <p class="alert-danger text-left" <?=form_error('barcode')?></p>
                </div>
            </div>
            <div class='form-group'>
                <label class='control-label col-md-2'> Harga
                </label>
                <div class='col-md-10'>
                    <input type='number' name='harga' class='form-control' value="<?php echo $venus['harga'];?>"/>
                    <p class="alert-danger text-left" <?=form_error('harga')?></p>
                </div>
            </div>
            <div class='form-group'>
                <div class='col-md-2'>
                    <input type='hidden' name='id' value="<?php echo $venus['id'];?>">
                </div>
                <div class='col-md-10'>
                    <input type='submit' name='simpan' class='btn btn-primary' value="Simpan"/>
                    <a href="<?php echo site_url();?>" class='btn btn-danger'>Kembali</a>
                </div>
            </div>
        </form>
    </div>
</div>