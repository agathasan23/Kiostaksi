<div class='col-md-12'>
    <h2 align='center'>Tabel Product</h2><br>
</div>
<div class='col-md-12'>
    <table class='table table-striped'>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Product</th>
                <th>Brand</th>
                <th>Barcode</th>
                <th>Harga</th>
                <th colspan=2 >Action</th>
            <tr>
        </thead>
        <tbody>
        <?php 
            $no=0;
            foreach($semua->result_array()as $d)
            {
                $no++;
         ?>
            <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $d['product'];?></td>
                <td><?php echo $d['brand'];?></td>
                <td><?php echo $d['barcode'];?></td>
                <td><?php echo $d['harga'];?></td>
                <td><a href="<?php echo site_url('product/form/'.$d['id']);?>" class='btn btn-success'>Edit</a></td>
                <td><a href="<?php echo site_url('product/hapus/'.$d['id']);?>" class='btn btn-danger'>Hapus</a></td>
            </tr>
            <?php 
            }
            ?>
        </tbody>
    </table>
    <a href="<?php echo site_url('product/form');?>" class='btn btn-primary pull-left'>Tambah Product</a>
</div>