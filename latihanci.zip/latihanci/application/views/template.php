<html>
<head>
<title>CRUD 2</title>
<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>
<div id='wrapper'>
    <nav class='navbar navbar-inverse'>
        <div class='navbar-header'>
            <a class='navbar-brand' href="<?php echo site_url();?>">CRUD 2</a>
        </div>
    </nav>
    <div id='page-wrapped'>
        <div class='container-fluid'>
            <div class='row'>
                <div class='col-md-2'>
                     <!-- sidebar kiri -->
                </div>
                <div class='col-md-8'>
                    <?php echo $content; ?>
                </div>
                <div class='col-md-2'>
                     <!-- sidebar kanan -->
                </div>
            </div>
        </div>
    </div>
</div>
<script scr="<?php echo base_url();?>assets/js/jquery.js"></script>
<script scr="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</body>
</html>