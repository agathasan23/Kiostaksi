<?php
defined('BASEPATH') or exit('Nodirect script accsess allowed');
class product extends CI_Controller
{
    private $alert='';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('productModel');
    }
    public function index()
    {
        $data['semua']= $this->productModel->all();
        $this->template('list',$data);

        $this->load->helper('tanggal');
        $waktu=date('Y-m-d');
        echo formatHariTanggal($waktu);
    }

    private function template($content,$data=null)
    {
        $data['content']=$this->load->view($content,$data,true);
        $this->load->view('template',$data);
    }
    private function alert($open_tag=null,$close_tag=null,$data=null)
    {
        if ($data!=null) $data=$open_tag.$data.$close_tag;
        return $data;
    }
    public function form()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('product','Nama Product','required|max_length[50]');
        $this->form_validation->set_rules('brand','Brand','required|max_length[50]');
        $this->form_validation->set_rules('deskripsi','Deskripsi','required|min_length[5]');
        $this->form_validation->set_rules('barcode','Barcode','required|max_length[30]');
        $this->form_validation->set_rules('harga','Harga','required|max_length[10]|integer');
        if ($this->form_validation->run())
       // if ($this->input->post('simpan'))
        {
            $array=array(
                'product'=>$this->input->post('product'),
                'brand'=>$this->input->post('brand'),
                'deskripsi'=>$this->input->post('deskripsi'),
                'barcode'=>$this->input->post('barcode'),
                'harga'=>$this->input->post('harga'),

            );
            if($this->input->post('id')=='')
            {
                if($this->productModel->insert($array))
                {
?>
                    <script>windows.alert('Berhasil Tersimpan');</script>
<?php
                    redirect('product','refresh');
                }
                else
                {
                    $this->alert=$this->alert("<p class='alert alert-danger'>","</p>","Gagal Disimpan");
                }
           
            }
            else
            {
                if($this->productModel->update($array,array('id'=>$this->input->post('id'))))
                {
                    ?>
                    <script>windows.alert('Sukses Tersimpan');</script>
                    <?php
                    redirect('product','refresh');
                }
                else
                {
                    $this->alert=$this->alert("<p class='alert alert-danger'>","</p>","Gagal Tersimpan");
                }
            }
        }
        $data['venus']=$this->productModel->getWhere(array('id'=>$this->uri->segment(3)))-> row_array();
        $data['alert']=$this->alert;
        $this->template('form',$data);
    }
    public function hapus()
    {
        if($this->uri->segment(3))
        $this->productModel->delete(array('id'=>$this->uri->segment(3)));
        redirect('product');
    }
} 
