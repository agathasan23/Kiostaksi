<?php
defined('BASEPATH') or exit ('No direct script access allowed');
class productModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    public function all()
    {
        return $this->db->get('product');
    }
    public function getWhere($where)
    {
        $this->db->where($where);
        return $this->db->get('product');
    }
    public function insert($data)
    {
        return $this->db->insert('product',$data);
    }
    public function update($data,$where)
    {
        $this->db->where($where);
        return $this->db->update('product',$data);
    }
    public function delete($where)
    {
        return $this->db->delete('product',$where);
    }
} 
?>